import { initServer } from "./configs/app.js"
import { connect } from "./configs/mong.js"

initServer()
connect()